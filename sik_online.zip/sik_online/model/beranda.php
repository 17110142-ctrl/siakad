</br>
<div class="container" style="height: 100%; display: flex; justify-content: center; align-items: center;">
    <div style="top: 50%; transform:translate(0, -50%); position: absolute;">
        <div class="well" style="margin-top: 0px;">
            <p align="center"><img src="images/logo.png" height="75" /></p>
            <h4 align="center" style="margin: 15px 0 -10px 0;"><b>SISTEM INFORMASI</br>STATUS KELULUSAN SISWA</b></h4>
            <?php require_once "setting-tgl.php" ?>
            <div class="form-group" style="margin-bottom: -10px;">
                <p align="center"><a href="model/caridata.php" class="btn btn-danger" value=""> CEK KELULUSAN </a></p>
            </div>
        </div>
        </br>
    </div>
</div>